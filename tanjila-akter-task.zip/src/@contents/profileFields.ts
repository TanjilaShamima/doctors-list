// Labels for patient profile panel
export const PROFILE_LABELS = {
    dateOfBirth: "Date Of Birth",
    gender: "Gender",
    contact: "Contact Info.",
    emergency: "Emergency Contacts",
    insurance: "Insurance Provider",
    showAll: "Show All Information",
};
