// Additional UI labels not covered in existing content files
export const UI_LABELS = {
    patients: 'Patients',
    diagnosticList: 'Diagnostic List',
    labResults: 'Lab Results',
    showAll: 'Show All Information'
};
